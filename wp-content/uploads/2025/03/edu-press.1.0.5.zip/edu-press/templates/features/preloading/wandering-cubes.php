<?php
/**
 * Preload Template: wandering cubes
 *
 * @package Edu_Press
 */
?>

<div class="sk-wandering-cubes">
	<div class="sk-cube sk-cube1"></div>
	<div class="sk-cube sk-cube2"></div>
</div>
